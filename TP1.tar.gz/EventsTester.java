import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowListener;
import java.awt.event.WindowStateListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class EventsTester 
	implements WindowListener, KeyListener, MouseListener, 
		WindowFocusListener, WindowStateListener, MouseWheelListener, MouseMotionListener {
	// ATTRIBUTS
	private JFrame mainFrame;
	private JFrame testFrame;
	private JButton newWindow;
	private JButton raz;
	
	/* 0 --> MouseListener
	 * 1 --> WindowFocusListener
	 * 2 --> WindowListener
	 * 3 --> KeyListener
	 * 4 --> WindowStateListener 
	 * 5 --> MouseWheelListener
	 * 6 --> MouseMotionListener
	 */
	private JTextArea[] area; 
	private int number;
	
	// CONSTRUCTEURS
	public EventsTester() {
		createView();
		placeComponents();
		createController();
	}
	
	// COMMANDES
	public void display() {
    	refresh();
        mainFrame.pack();
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }
	
	// OUTILS
	private void refresh() {
		// construction des fen�tres de visualisation des contr�les
		
	}
	
	private void createView() {
		final int frameWidth = 500;
        final int frameHeight = 500;
         
        mainFrame = new JFrame("Tests sur les �v�nements - Zone d'AFFICHAGE");
        mainFrame.setPreferredSize(new Dimension(frameWidth, frameHeight));
        
        // premi�re fen�tre de test non visible, sera d�truite d�s 
        // l'appui sur le bouton nouvelle fen�tre
        testFrame = new JFrame();
        	
        newWindow = new JButton("Nouvelle fen�tre");
        raz = new JButton("RAZ Compteur");
        
        number = 0;
        
        area = new JTextArea[7];
        
        // Zones de textes
        for (int k = 0 ; k < 7 ; k++) {
        	area[k] = new JTextArea();
        }
	}
	
	private void placeComponents() {
		// placement des boutons
		JPanel p = new JPanel(); {
			JPanel q = new JPanel(); {
				JPanel r = new JPanel(); {
					r.add(newWindow);
				}
				q.add(r);
				
				r = new JPanel(); {
					r.add(raz);
				}
				q.add(r);
			} 
			p.add(q, BorderLayout.CENTER);
		}
		mainFrame.add(p, BorderLayout.NORTH);
		
		// placement des zones de texte
		p = new JPanel(new GridLayout(3, 3)); {
			for (int k = 0 ; k < 7 ; k++) {
				JPanel q = new JPanel(); {
					        	
					// l�gene et bordure
					switch(k) {
		        		case 0 :
		        			q.setBorder(BorderFactory.createTitledBorder("MouseListener"));
		        			break;
		        		case 1 :
		        			q.setBorder(BorderFactory.createTitledBorder("WindowFocusListener"));
		        			break;
		        		case 2 : 
		        			q.setBorder(BorderFactory.createTitledBorder("WindowListener"));
		        			break;
		        		case 3 : 
		        			q.setBorder(BorderFactory.createTitledBorder("KeyListener"));
		        			break;
		        		case 4 : 
		        			q.setBorder(BorderFactory.createTitledBorder("WindowStateListener"));
		        			break;
		        		case 5 : 
		        			q.setBorder(BorderFactory.createTitledBorder("MouseWheelListener"));
		        			break;
		        		case 6 : 
		        			q.setBorder(BorderFactory.createTitledBorder("MouseMotionListener"));
		        			break;
		        	}
					
					q.add(area[k]);
					
					// d�filement
		        	JScrollPane s = new JScrollPane(q, 
		        			JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		        	
					q.add(s);
				}	
				p.add(q);
			}
		}
		
		p.setBorder(BorderFactory.createLineBorder(Color.black));
		
		mainFrame.add(p);
	}
	
	private void createController() {
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// nouvelle fen�tre
		newWindow.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	// suppression de l'ancienne fen�tre
            	testFrame.dispose();
            	createNewTestFrame();
            }
        });
		
		// r�initialisation du compteur
		raz.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	number = 0;
            	razNumber();
            }
        });
				
	}
	
	/*
	 * Cr�ation d'une nouvelle fen�tre de test
	 */
	private void createNewTestFrame() {
		final int frameWidth = 200;
        final int frameHeight = 100;
         
        testFrame = new JFrame("zone de test");
        testFrame.setPreferredSize(new Dimension(frameWidth, frameHeight));
        
        testFrame.pack();
        testFrame.setLocationRelativeTo(null);
        testFrame.setVisible(true);
        
        testFrame.addMouseListener(this);
        testFrame.addWindowFocusListener(this);
        testFrame.addWindowListener(this);
        testFrame.addKeyListener(this);
        testFrame.addWindowStateListener(this);
        testFrame.addMouseWheelListener(this);
        testFrame.addMouseMotionListener(this);
        
        testFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);    
	}
	
	private void razNumber() {
		for (int k = 0 ; k < 7 ; k++) {
        	area[k].append("--- RAZ 1 ---\n");
        }
	}

	// Gestion des diff�rents �venements 
	@Override
	public void windowGainedFocus(WindowEvent e) {
		area[1].append(number + " WINDOW_GAINED_FOCUS\n");
		++number;
	}

	@Override
	public void windowLostFocus(WindowEvent e) {
		area[1].append(number + " WINDOW_LOST_FOCUS\n");
		++number;
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		area[6].append(number + " MOUSE_DRAGGED\n");
		++number;
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		area[6].append(number + " MOUSE_MOVED\n");
		++number;
	}

	@Override
	public void mouseWheelMoved(MouseWheelEvent e) {
		area[5].append(number + " MOUSE_WHEEL_MOVED\n");
		++number;
	}

	@Override
	public void windowStateChanged(WindowEvent e) {
		area[4].append(number + " WINDOW_STATE_CHANGE\n");
		++number;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		area[0].append(number + " MOUSE_CLICKED\n");
		++number;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		area[0].append(number + " MOUSE_PRESSED\n");
		++number;
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		area[0].append(number + " MOUSE_RELEASED\n");
		++number;
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		area[0].append(number + " MOUSE_ENTERED\n");
		++number;
	}

	@Override
	public void mouseExited(MouseEvent e) {
		area[0].append(number + " MOUSE_EXITED\n");
		++number;
	}

	@Override
	public void keyTyped(KeyEvent e) {
		area[3].append(number + " KEY_LISTENER\n");
		++number;
	}

	@Override
	public void keyPressed(KeyEvent e) {
		area[3].append(number + " KEY_PRESSED\n");
		++number;
	}

	@Override
	public void keyReleased(KeyEvent e) {
		area[3].append(number + " KEY_RELEASED\n");
		++number;
	}

	@Override
	public void windowOpened(WindowEvent e) {
		area[2].append(number + " WINDOW_LISTENER\n");
		++number;
	}

	@Override
	public void windowClosing(WindowEvent e) {
		area[2].append(number + " WINDOW_CLOSING\n");
		++number;
	}

	@Override
	public void windowClosed(WindowEvent e) {
		area[2].append(number + " WINDOW_CLOSED\n");
		++number;
	}

	@Override
	public void windowIconified(WindowEvent e) {
		area[2].append(number + " WINDOW_Iconified\n");
		++number;
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		area[2].append(number + " WINDOW_Deiconified\n");
		++number;
	}

	@Override
	public void windowActivated(WindowEvent e) {
		area[2].append(number + " WINDOW_ACTIVATED\n");
		++number;
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		area[2].append(number + " WINDOW_DEACTIVATED\n");
		++number;
	}
	
	// LANCEUR
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new EventsTester().display();
            }
        });
	}
}
