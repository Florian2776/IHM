package serie01;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowListener;
import java.awt.event.WindowStateListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class EventsTester 
	implements WindowListener, KeyListener, MouseListener, 
		WindowFocusListener, WindowStateListener, MouseWheelListener, MouseMotionListener {
	
	
	// CONSTANTES
	/* 0 --> MouseListener
	 * 1 --> WindowFocusListener
	 * 2 --> WindowListener
	 * 3 --> KeyListener
	 * 4 --> WindowStateListener 
	 * 5 --> MouseWheelListener
	 * 6 --> MouseMotionListener
	 */
	public final static String[] NAME_EVENTS = {"MouseListener","WindowFocusListener", 
			"WindowListener", "KeyListener", "WindowStateListener", 
			"MouseWheelListener", "MouseMotionListener"}; 
	
	// ATTRIBUTS
	private JFrame mainFrame;
	private JFrame testFrame;
	private JButton newWindow;
	private JButton raz;
	
	private JTextArea[] area; 
	private int number;
	
	// CONSTRUCTEURS
	public EventsTester() {
		createView();
		placeComponents();
		createController();
	}
	
	// COMMANDES
	public void display() {
    	refresh();
        mainFrame.pack();
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }
	
	// OUTILS
	private void refresh() {
		// construction des fen�tres de visualisation des contr�les
		
	}
	
	private void createView() {
		final int frameWidth = 500;
        final int frameHeight = 500;
         
        mainFrame = new JFrame("Tests sur les �v�nements - Zone d'AFFICHAGE");
        mainFrame.setPreferredSize(new Dimension(frameWidth, frameHeight));
        
        // premi�re fen�tre de test non visible, sera d�truite d�s 
        // l'appui sur le bouton nouvelle fen�tre
        testFrame = new JFrame();
        	
        newWindow = new JButton("Nouvelle fen�tre");
        raz = new JButton("RAZ Compteur");
        
        number = 0;
        
        area = new JTextArea[NAME_EVENTS.length];
        
        // Zones de textes
        for (int k = 0 ; k < NAME_EVENTS.length ; k++) {
        	area[k] = new JTextArea();
        }
	}
	
	private void placeComponents() {
		// placement des boutons
		JPanel p = new JPanel(); {
			JPanel q = new JPanel(); {
				JPanel r = new JPanel(); {
					r.add(newWindow);
				}
				q.add(r);
				
				r = new JPanel(); {
					r.add(raz);
				}
				q.add(r);
			} 
			p.add(q, BorderLayout.CENTER);
		}
		mainFrame.add(p, BorderLayout.NORTH);
		
		// placement des zones de texte
		p = new JPanel(new GridLayout(3, 3)); {
			for (int k = 0 ; k < NAME_EVENTS.length ; k++) {
				JPanel q = new JPanel(); {
					        	
					// l�gende et bordure
					q.setBorder(BorderFactory.createTitledBorder(NAME_EVENTS[k]));
					q.add(area[k]);
					
					// d�filement
		        	JScrollPane s = new JScrollPane(q);
		        	
					p.add(s);
				}	
			}
		}
		
		// bordure du JPanel principale
		p.setBorder(BorderFactory.createLineBorder(Color.black));
		
		mainFrame.add(p);
	}
	
	private void createController() {
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// nouvelle fen�tre
		newWindow.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	// suppression de l'ancienne fen�tre
            	testFrame.dispose();
            	createNewTestFrame();
            }
        });
		
		// r�initialisation du compteur
		raz.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	razNumber();
            }
        });
				
	}
	
	/*
	 * Cr�ation d'une nouvelle fen�tre de test
	 */
	private void createNewTestFrame() {
		final int frameWidth = 200;
        final int frameHeight = 100;
         
        testFrame = new JFrame("zone de test");
        testFrame.setPreferredSize(new Dimension(frameWidth, frameHeight));
        
        testFrame.pack();
        testFrame.setLocationRelativeTo(null);
        testFrame.setVisible(true);
        
        testFrame.addMouseListener(this);
        testFrame.addWindowFocusListener(this);
        testFrame.addWindowListener(this);
        testFrame.addKeyListener(this);
        testFrame.addWindowStateListener(this);
        testFrame.addMouseWheelListener(this);
        testFrame.addMouseMotionListener(this);
        
        testFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);    
	}
	
	/**
	 * R�initialise le compteur d'�venements 
	 * et affiche dans chaque JTextArea une s�paration 
	 * indiquant la s�paration.
	 * 
	 *  @post : 
	 *  	number == 0
	 *  		
	 */
	private void razNumber() {
		for (int k = 0 ; k < NAME_EVENTS.length ; k++) {
        	area[k].append("--- RAZ 1 ---\n");
        }
		number = 0;
	}

	// Gestion des diff�rents �venements 
	
	// remarque : � la place d'implanter les m�thodes de cette fa�on, 
	// nous aurions pu, tout aussi bien, les mettre directement dans des classes que nous 
	// (r�)implantons directement dans notre code, ce qui n'obligerait plus
	// notre classe � implanter implements WindowListener, KeyListener, MouseListener etc. 
	@Override
	public void windowGainedFocus(WindowEvent e) {
		area[1].append(number + " WINDOW_GAINED_FOCUS\n");
		++number;
	}

	@Override
	public void windowLostFocus(WindowEvent e) {
		area[1].append(number + " WINDOW_LOST_FOCUS\n");
		++number;
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		area[6].append(number + " MOUSE_DRAGGED\n");
		++number;
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		area[6].append(number + " MOUSE_MOVED\n");
		++number;
	}

	@Override
	public void mouseWheelMoved(MouseWheelEvent e) {
		area[5].append(number + " MOUSE_WHEEL_MOVED\n");
		++number;
	}

	@Override
	public void windowStateChanged(WindowEvent e) {
		area[4].append(number + " WINDOW_STATE_CHANGE\n");
		++number;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		area[0].append(number + " MOUSE_CLICKED\n");
		++number;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		area[0].append(number + " MOUSE_PRESSED\n");
		++number;
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		area[0].append(number + " MOUSE_RELEASED\n");
		++number;
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		area[0].append(number + " MOUSE_ENTERED\n");
		++number;
	}

	@Override
	public void mouseExited(MouseEvent e) {
		area[0].append(number + " MOUSE_EXITED\n");
		++number;
	}

	@Override
	public void keyTyped(KeyEvent e) {
		area[3].append(number + " KEY_LISTENER\n");
		++number;
	}

	@Override
	public void keyPressed(KeyEvent e) {
		area[3].append(number + " KEY_PRESSED\n");
		++number;
	}

	@Override
	public void keyReleased(KeyEvent e) {
		area[3].append(number + " KEY_RELEASED\n");
		++number;
	}

	@Override
	public void windowOpened(WindowEvent e) {
		area[2].append(number + " WINDOW_LISTENER\n");
		++number;
	}

	@Override
	public void windowClosing(WindowEvent e) {
		area[2].append(number + " WINDOW_CLOSING\n");
		++number;
	}

	@Override
	public void windowClosed(WindowEvent e) {
		area[2].append(number + " WINDOW_CLOSED\n");
		++number;
	}

	@Override
	public void windowIconified(WindowEvent e) {
		area[2].append(number + " WINDOW_Iconified\n");
		++number;
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		area[2].append(number + " WINDOW_Deiconified\n");
		++number;
	}

	@Override
	public void windowActivated(WindowEvent e) {
		area[2].append(number + " WINDOW_ACTIVATED\n");
		++number;
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		area[2].append(number + " WINDOW_DEACTIVATED\n");
		++number;
	}
	
	// LANCEUR
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new EventsTester().display();
            }
        });
	}
}
