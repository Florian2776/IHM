package serie07.gui;

import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

import serie07.util.ValueTranslator;

public class FilterablePane {
	
	// ATTRIBUTS
	private JPanel panel;
	private JTextField filterText;
	private JComboBox filterTypes;
	private ValueTranslator filterableList;
	private ValueTranslator translator;
	
	
	// CONSTRUCTEURS
	public FilterablePane() {
		createModel();
		createView();
		placeComponents();
		createController();
	}
	
	// OUTILS
	private void createModel() {
		
	}
	
	private void createView() {
		panel = new JPanel();
		filterText = new JTextField();
		filterTypes = new JComboBox();
	}
	
	private void placeComponents() {
		panel.add(filterTypes);
	}
	
	private void createController() {
		
	}
}
