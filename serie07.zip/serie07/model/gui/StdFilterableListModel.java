package serie07.model.gui;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Observer;

import javax.swing.event.ListDataListener;

import serie07.model.filters.Filter;
import serie07.model.filters.Filterable;

public class StdFilterableListModel<E extends Filterable<V>, V> implements FilterableListModel<E, V> {

	private List<E> initialList;
	private List<E> filtredList;
	private Filter<E, V> filter;
	private PropertyChangeListener observer;
	
	public StdFilterableListModel() {
		initialList = new ArrayList<E>();
		filtredList = new ArrayList<E>();
		observer = new PropertyChangeListener() {
			@Override
			public void propertyChange(PropertyChangeEvent evt) {
				// TODO Auto-generated method stub
				
			}
		};
		
		filter = null;
	}
	
	/**
     * Le filtre actuel de ce mod�le filtrable.
     */
    public Filter<E, V> getFilter() {
    	return filter;
    }
    
    /**
     * Le i�me �l�ment de la liste filtr�e.
     * @pre <pre>
     *     0 <= i < getSize() </pre>
     */
    public E getElementAt(int i) {
    	if (0 > i || i >= getSize()) {
    		throw new AssertionError();
    	}
    	return filtredList.get(i);
    }
    
    /**
     * Le nombre total d'�l�ments de la liste filtr�e.
     */
    public int getSize() {
    	return filtredList.size();
    }
    
    /**
     * Le i�me �l�ment de la liste initiale.
     * @pre <pre>
     *     0 <= i < getUnfilteredSize() </pre>
     */
    public E getUnfilteredElementAt(int i) {
    	if (0 > i || i >= getSize()) {
    		throw new AssertionError();
    	}
    	return initialList.get(i);
    }
    
    /**
     * Le nombre total d'�l�ments de la liste initiale.
     */
    public int getUnfilteredSize() {
    	return initialList.size();
    }

    // COMMANDES
    
    /**
     * Ajoute un �l�ment dans le mod�le.
     * @pre <pre>
     *     element != null </pre>
     * @post <pre>
     *     getUnfilteredSize() == old getUnfilteredSize() + 1
     *     getUnfilteredElementAt(getUnfilteredSize() - 1) == element </pre>
     */
    public void addElement(E element) {
    	if (element == null) {
    		throw new AssertionError();
    	}
    	initialList.add(element);
    }
    
    /**
     * Fixe le filtre de ce mod�le.
     * @post <pre>
     *     getFilter() == filter </pre>
     */
    public void setFilter(Filter<E, V> filter) {
    	this.filter = filter;
    	// TODO 
    	// notificaction
    }
    
    /**
     * R�initialise le mod�le avec tous les �l�ments de c.
     * @pre <pre>
     *     c != null </pre>
     * @post <pre>
     *     getUnfilteredSize() == c.getSize()
     *     forall e:E :
     *         c.contains(e)
     *             <==> exists i:[0..getUnfilteredSize()[ :
     *                     getUnfilteredElementAt(i) == e </pre>
     */
    public void setElements(Collection<E> c) {
    	if (c == null) {
    		throw new AssertionError();
    	}
    	initialList.clear();
    	for (E e : c) {
    		initialList.add(e);
    	}
    }

	@Override
	public void addListDataListener(ListDataListener l) {
		
	}

	@Override
	public void removeListDataListener(ListDataListener l) {
	}
}
